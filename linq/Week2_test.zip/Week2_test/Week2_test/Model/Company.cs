﻿namespace Week2_test.Model
{
    public class Company
    {
        public int CompanyId {  get; set; }
        public string CompanyName { get; set;}
        public string City {  get; set;}
        public string Address { get; set;}
    }
}

﻿namespace Week2_test.Model
{
    public class Student
    {
        public int StudId { get; set; }
        public string StudName { get; set; }
        public string Qualification {  get; set; }
        public string Skill {  get; set; }
    }
}
